package com.tcsglobal.issuetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssuetrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
